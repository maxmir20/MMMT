(function() {
    var scroll = document.querySelector('div[class*="jobs-description__content jobs-description-content"]')

    if (scroll != undefined){
        console.log('we made it!')
        scroll.scrollIntoView(true);
        return true
    }

})();
