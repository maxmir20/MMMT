//Part 0: upload stored template from extension (eventually replace with file upload)
chrome.runtime.onInstalled.addListener(function (object) {
    const url = chrome.runtime.getURL('helloworld.tex')

    fetch(url)
        .then(function(response) {
            response.text().then(function(text) {
                chrome.storage.local.set({ 'helloworld.tex: text }, function() {
                console.log('Uploading stored template files.');
    });        }

    chrome.storage.local.set({ 'helloworld': selectedText }, function() {
        console.log('Uploading stored template files.');
    });
}

(function() {
    var scroll = document.querySelector('div[class*="jobs-description__content jobs-description-content"]')

    if (scroll != undefined){
        console.log('we made it!')
        scroll.scrollIntoView(true);
        return true
    }

})();
