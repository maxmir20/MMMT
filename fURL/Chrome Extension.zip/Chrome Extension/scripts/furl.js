//Stage 0 Access URL via temp DOM
function copyURL(){
//    use dummy element so we can
//  access the href so we can get the URL
    let url = window.location.href;
//    trim the url of any utm elements
    let trimmed_url = trimURL(url);
//    copy to clipboard
    navigator.clipboard.writeText(trimmed_url).then(() => {
        console.log("successfully wrote url to clipboard")
    }, () => {
        console.log("failed to write url to clipboard")
    }


}

// V1 on click
// Stage 1 Copy URL and trim UTM (edge cases for http and outmost)

// Stage 2 Using Clipboard API, copy to clipboard

// V2 monitor clipboard?
// Stage 3: if UTM in clipboard, read and then edit?

// Stage 4, link to website db?


function trimURL(url){
//    const url = tabs[0].url
    // search for query parameters
    const path_split = url.split('?')
    if  (path_split.length < 2) {
        
    }
    return path_split;
  }

//// Example
//const url = getURL()

browser.tabs
    .query({currentWindow: true, active: true})
    .then(copyURL, onError);
    
