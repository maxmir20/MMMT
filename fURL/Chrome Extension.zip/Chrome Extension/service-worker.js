chrome.tabs.query({activate:true, currentWindow:true}, function(tabs){
    chrome.tabs.sendMessage(tabs[0].id,
        {
            message:
        })
})